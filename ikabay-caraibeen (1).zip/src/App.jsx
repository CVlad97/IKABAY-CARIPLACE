import React from 'react'

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-white to-orange-100 text-gray-800 p-6">
      <h1 className="text-4xl font-bold text-center mb-4">🌴 Ikabay Caraïbeen 🌴</h1>
      <p className="text-center text-lg max-w-2xl mx-auto">
        Marketplace caribéenne multilingue : produits locaux & importés, crypto-récompenses, livraison mutualisée,
        jeux culturels, emploi et plus !
      </p>
    </div>
  )
}

export default App
