# Ikabay Caraïbeen 🌴

**Ikabay Caraïbeen** est une marketplace caribéenne multilingue et moderne, conçue pour concurrencer AliExpress, Temu et Shein, tout en valorisant les produits locaux des DOM-TOM et de la Caraïbe.

## 🌐 Fonctionnalités prévues :
- Marketplace locale & internationale
- Paiement classique et crypto (Token IKB)
- Emploi DOM-TOM
- Jeux culturels caribéens
- Livraison communautaire et mutualisée
- Dashboard multi-rôle
- Multilingue (Français, Anglais, Créole)
- Compatible TikTok Shopping & WhatsApp Business

## 🚀 Technologies
- React + Vite + Tailwind CSS
- Déploiement Vercel
- Backend (à venir) : Supabase ou Airtable
- Intégration API : AliExpress, DHL, Amazon, Zapier, WhatsApp

## 📁 Pages prévues :
- Accueil
- Marketplace
- Crypto IKB
- Emploi
- Jeux caribéens
- Actualités DOM-TOM
- Aide / SOS Galère

## 🛠 En cours :
- Intégration crypto & dashboard
- Liaison base de données (produits, utilisateurs)
- Déploiement GitHub + Vercel
